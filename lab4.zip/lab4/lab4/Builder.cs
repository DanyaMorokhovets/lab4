﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace Lab4
{
    public class DataGridViewBuilder
    {
        private DataGridView dataGridView;
        private ICloneableColumn columnPrototype;

        public int ColumnCount => dataGridView.Columns.Count;

        public DataGridViewBuilder(DataGridView dataGridView)
        {
            this.dataGridView = dataGridView;
            this.columnPrototype = new DataGridViewColumnPrototype(new DataGridViewTextBoxColumn());
        }

        public void AddColumn(string columnName, List<string> values)
        {
            DataGridViewTextBoxColumn column = (columnPrototype.Clone() as DataGridViewColumnPrototype).GetColumn();
            column.HeaderText = columnName;

            dataGridView.Columns.Add(column);

            while (dataGridView.Rows.Count < values.Count)
            {
                dataGridView.Rows.Add();
            }

            for (int i = 0; i < values.Count; i++)
            {
                dataGridView.Rows[i].Cells[ColumnCount - 1].Value = values[i];
            }
        }

        public void RemoveLastColumn()
        {
            if (ColumnCount > 0)
            {
                dataGridView.Columns.RemoveAt(ColumnCount - 1);
            }
        }

        public void CopyLastColumn()
        {
            if (ColumnCount > 0)
            {
                DataGridViewTextBoxColumn lastColumn = dataGridView.Columns[ColumnCount - 1] as DataGridViewTextBoxColumn;
                if (lastColumn != null)
                {
                    DataGridViewTextBoxColumn copiedColumn = (columnPrototype.Clone() as DataGridViewColumnPrototype).GetColumn();
                    copiedColumn.HeaderText = lastColumn.HeaderText + " Копія";

                    dataGridView.Columns.Add(copiedColumn);

                    for (int i = 0; i < dataGridView.Rows.Count; i++)
                    {
                        dataGridView.Rows[i].Cells[ColumnCount - 1].Value = dataGridView.Rows[i].Cells[ColumnCount - 2].Value;
                    }
                }
            }
        }

    }
}

