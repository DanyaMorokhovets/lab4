﻿using Lab4;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab4
{
    public partial class Form1 : Form
    {
        private DataGridViewBuilder dataGridViewBuilder;

        public Form1()
        {
            InitializeComponent();
            InitializeCheckedListBoxEvents();
            dataGridViewBuilder = new DataGridViewBuilder(dataGridView1);
        }

        private void InitializeCheckedListBoxEvents()
        {
            checkedListBox1.ItemCheck += CheckedListBox_ItemCheck;
            checkedListBox2.ItemCheck += CheckedListBox_ItemCheck;
            checkedListBox3.ItemCheck += CheckedListBox_ItemCheck;
            checkedListBox4.ItemCheck += CheckedListBox_ItemCheck;
        }

        private void CheckedListBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            CheckedListBox checkedListBox = sender as CheckedListBox;

            for (int ix = 0; ix < checkedListBox.Items.Count; ++ix)
            {
                if (ix != e.Index)
                {
                    checkedListBox.SetItemChecked(ix, false);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IsAllChecked(checkedListBox1) && IsAllChecked(checkedListBox2) && IsAllChecked(checkedListBox3) && IsAllChecked(checkedListBox4))
            {
                List<string> selectedItems = new List<string>();
                selectedItems.AddRange(GetSelectedItems(checkedListBox1));
                selectedItems.AddRange(GetSelectedItems(checkedListBox2));
                selectedItems.AddRange(GetSelectedItems(checkedListBox3));
                selectedItems.AddRange(GetSelectedItems(checkedListBox4));

                string columnName = textBox1.Text.Trim();

                if (string.IsNullOrEmpty(columnName))
                {
                    columnName = "Конфігурація " + (dataGridViewBuilder.ColumnCount + 1);
                }

                dataGridViewBuilder.AddColumn(columnName, selectedItems);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridViewBuilder.ColumnCount > 0)
            {
                dataGridViewBuilder.RemoveLastColumn();
            }
        }

        private bool IsAllChecked(CheckedListBox checkedListBox)
        {
            return checkedListBox.CheckedItems.Count > 0;
        }

        private List<string> GetSelectedItems(CheckedListBox checkedListBox)
        {
            List<string> selectedItems = new List<string>();
            for (int i = 0; i < checkedListBox.CheckedItems.Count; i++)
            {
                selectedItems.Add(checkedListBox.CheckedItems[i].ToString());
            }
            return selectedItems;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridViewBuilder.CopyLastColumn();
        }

    }
}

