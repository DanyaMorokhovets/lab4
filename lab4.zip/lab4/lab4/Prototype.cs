﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Lab4
{
    public interface ICloneableColumn
    {
        ICloneableColumn Clone();
    }

    public class DataGridViewColumnPrototype : ICloneableColumn
    {
        private DataGridViewTextBoxColumn column;

        public DataGridViewColumnPrototype(DataGridViewTextBoxColumn column)
        {
            this.column = column;
        }

        public ICloneableColumn Clone()
        {
            return new DataGridViewColumnPrototype(column);
        }

        public DataGridViewTextBoxColumn GetColumn()
        {
            return new DataGridViewTextBoxColumn
            {
                HeaderText = column.HeaderText
            };
        }
    }
}
